
package com.pss.substituirmarca.Collection;

import com.pss.substituirmarca.presenter.PrincipalPresenter;
import java.util.ArrayList;


public class MarcasCollection {

    private static MarcasCollection instancia;
    private ArrayList<String> marcaCollection;
    private PrincipalPresenter observer;

    private MarcasCollection() {
        marcaCollection = new ArrayList<>();
        observer = PrincipalPresenter.getInstance();
    }

    public static MarcasCollection getInstance() {
        if (instancia == null) {
            instancia = new MarcasCollection();
            return instancia;
        } else {
            return instancia;
        }
    }

    public boolean add(String marca) throws IndexOutOfBoundsException {
        try {
            boolean existe = false;
            for (String texto : marcaCollection) {
                if (texto.equals(marca)) {
                    existe = true;
                }
            }
            if (!existe) {
                marcaCollection.add(marca);
                notifyObservers();
            }
            return existe;
        } catch (IndexOutOfBoundsException e) {
            throw e;
        }
    }

    public void remove(String marca) throws IndexOutOfBoundsException{
        try {
            for (int i = 0; i < marcaCollection.size(); i++) {
                if (marcaCollection.get(i).equalsIgnoreCase(marca)) {
                    marcaCollection.remove(i);
                }
            }
            notifyObservers();
        } catch (IndexOutOfBoundsException e) {
            throw e;
        }
    }

    public void notifyObservers() {
        observer.update(marcaCollection);
    }

    public ArrayList<String> getMarcaCollection() {
        return marcaCollection;
    }

}
