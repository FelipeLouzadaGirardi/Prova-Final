
package com.pss.substituirmarca.presenter;

import com.pss.substituirmarca.Collection.MarcasCollection;
import com.pss.substituirmarca.model.ProcessadoraModel;
import com.pss.substituirmarca.view.PrincipalView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;


public class PrincipalPresenter {

    private PrincipalView principal;
    private static PrincipalPresenter instancia;

    private PrincipalPresenter() {
        principal = new PrincipalView();
        principal.setLocationRelativeTo(principal.getParent());
        principal.getTxtAreaProcessado().setEditable(false);
        principal.getTableMarcasRemovidas().setDefaultEditor(Object.class, null);
        principal.setVisible(true);
        iniciarTela();
    }

    public void iniciarTela() {
        principal.getBtnAdicionar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String marca = JOptionPane.showInputDialog(principal, "Digite o nome da Marca \nDetalhe Letras maiúsculas e miniculas são diferenciadas");
                    if (marca != null) {
                        boolean existe = MarcasCollection.getInstance().add(marca);
                        if (existe) {
                            JOptionPane.showMessageDialog(principal, "O registro já existe");
                        } else {
                            principal.getTxtAreaProcessado().setText("");
                            JOptionPane.showMessageDialog(principal, "Registro adicionado");
                        }
                    }
                } catch (IndexOutOfBoundsException ex) {
                    JOptionPane.showMessageDialog(principal, "Erro ao inserir");
                }
            }
        });
        principal.getBtnRemover().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    JTable tabela = principal.getTableMarcasRemovidas();
                    DefaultTableModel model = (DefaultTableModel) tabela.getModel();
                    Vector dado = model.getDataVector().elementAt(tabela.getSelectedRow());
                    MarcasCollection.getInstance().remove(dado.get(0).toString());
                    principal.getTxtAreaProcessado().setText("");
                    JOptionPane.showMessageDialog(principal, "Registro removido");
                } catch (IndexOutOfBoundsException ex) {
                    JOptionPane.showMessageDialog(principal, "Selecione uma linha");
                }
            }
        });
        principal.getBtnProcessar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (principal.getTxtAreaOriginal().getText().isEmpty()) {
                    JOptionPane.showMessageDialog(principal, "Texto Para processamento está vazio");
                } else if (MarcasCollection.getInstance().getMarcaCollection().isEmpty()) {
                    principal.getTxtAreaProcessado().setText(principal.getTxtAreaOriginal().getText());
                } else {
                    principal.getTxtAreaProcessado().setText(new ProcessadoraModel().
                            processar(principal.getTxtAreaOriginal().getText()));
                }
            }
        });
        principal.getTxtAreaOriginal().getDocument().addDocumentListener(new DocumentListener() {
            //Neste caso foi utilizado o nome completo da classe DocumentEvent pois não é aceito
            //o nome através de import
            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
            }

            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                principal.getTxtAreaProcessado().setText("");
            }
        });
    }

    public static PrincipalPresenter getInstance() {
        if (instancia == null) {
            instancia = new PrincipalPresenter();
            return instancia;
        } else {
            return instancia;
        }
    }

    public void update(ArrayList<String> marcas) {
        JTable tabela = principal.getTableMarcasRemovidas();
        DefaultTableModel model = (DefaultTableModel) tabela.getModel();
        model.setNumRows(0);
        for (String marca : marcas) {
            model.addRow(new Object[]{marca});
        }
    }

}
