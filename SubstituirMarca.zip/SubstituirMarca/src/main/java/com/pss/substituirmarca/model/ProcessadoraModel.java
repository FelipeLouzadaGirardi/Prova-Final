
package com.pss.substituirmarca.model;

import com.pss.substituirmarca.Collection.MarcasCollection;
import java.util.ArrayList;

public class ProcessadoraModel {
    private ArrayList<String> marcaCollection;
    
    public ProcessadoraModel(){
        marcaCollection = MarcasCollection.getInstance().getMarcaCollection();
    }
    
    public String processar(String texto){
        for(String marca : marcaCollection){
            texto = UtilitarioStringModel.getInstance().substitui(texto, marca, "*");
        }
        return texto;
    }
}
