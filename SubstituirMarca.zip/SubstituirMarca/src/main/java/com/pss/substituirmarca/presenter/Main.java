
package com.pss.substituirmarca.presenter;

public class Main {
    public static void main(String[] args) {
        PrincipalPresenter.getInstance();
    }
}
