
package com.pss.substituirmarca.model;

public class UtilitarioStringModel {
    private static UtilitarioStringModel instancia;
    
    private UtilitarioStringModel(){
        
    }
    
    public static UtilitarioStringModel getInstance(){
        if (instancia == null) {
            instancia = new UtilitarioStringModel();
            return instancia;
        } else {
            return instancia;
        }
    }
    
    public String substitui(String texto, String palavra, String simbolo){
        String substituição = "";
        for(int i = 0; i < palavra.length(); i++){
            substituição += simbolo;
        }
        String nova = texto.replaceAll(palavra, substituição);
        return nova;
    }
}
